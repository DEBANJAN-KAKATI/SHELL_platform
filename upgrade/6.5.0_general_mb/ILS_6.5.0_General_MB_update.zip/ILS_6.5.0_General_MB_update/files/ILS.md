# ILS — platform reference

"ILS" is the name for this application: the **ILS Dashboard** (README title "DHA Data Dashboard"), version
in `VERSION` (6.5.0). It is a local Flask web app for a pilot-plant test rig: it loads gas-chromatography DHA
(Detailed Hydrocarbon Analysis) results, online process/historian data and the Run Plan workbook, joins them by
timestamp and reactor, calculates yields, and offers plots, a printable summary dashboard and saved runs.
Three processes: **Isomerization** (original, reactors R1–R8), **Reforming** (v6.4, Reactor 1 only) and **General_MB**
(v6.5.0: Isomerization pages + Internal Standard mass balance on Online Analysis).

## Run / stack
- Python 3, Flask 3, pandas 2, olefile + xlrd (legacy `.XLS` read via the OLE `Workbook`/`Book` stream), openpyxl.
- Windows-first: `run_dashboard.bat` picks Python in order: working `.venv` / `.venv-local` → installed Python 3.9+
  (`py`, PATH, `%LOCALAPPDATA%\Programs\Python\Python3*`, `%LOCALAPPDATA%\Python\pythoncore-*`, Program Files) that already
  imports the app (used directly, no downloads) → new venv (`--system-site-packages`) from an installed Python, or that Python
  directly if venv fails → downloaded embeddable 3.12 in `.python-runtime` only when no Python is installed (its
  `python312._pth` includes `..` so `import app` works). pip runs only when packages are missing or `requirements.txt`
  differs from the stamp `ils-requirements.txt` next to python.exe; a `wheels` folder enables offline install; a failed pip
  is tolerated when the app still imports. Company networks may answer 403 for python.org / pypi.org.
  `run_app.py` moves to the next free port when 5001 is busy/reserved and reuses an already running dashboard.
  Keep `.bat` files CRLF (`.gitattributes`); test exit codes with `neq 0`; avoid set-and-use of a variable inside one
  `( )` block. The embeddable runtime has no tkinter, so Browse uses the PowerShell dialog fallback in `dialog_service.py`.
- pandas: 2.x on Python ≤3.14, 3.x on 3.15+ (requirements markers). Parse ISO timestamps with `format="ISO8601"` —
  pandas 3 applies `dayfirst=True` to ISO dates.
- `config/settings.json`: host, port, `open_browser`, default DHA folder, valve-opening (reactor map) folder,
  Run Plan file (paths point at `C:\Users\...\ILS_App\Data\...`).
- Env vars: `DASHBOARD_USER` + `DASHBOARD_PASS` (both set → login required, for sharing over a tunnel;
  `stop_sharing.bat`), `DASHBOARD_SECRET_KEY`, `DASHBOARD_DATA_INTEGRITY=0` hides Data Integrity.
- `pytest.ini` expects `tests/`, but no tests are committed. Data files (`*.xls/xlsx/csv`, `DHA/`, `RunData/*`,
  `Historian/*.sqlite`, `backups/`) are git-ignored.
- Native file/folder pickers: `backend/services/dialog_service.py` (tkinter via `picker.py`, PowerShell fallback).

## Layout
- `app.py` — `create_app()`: registers blueprints `api`, `historian_api`, `run_data_api`, `reforming_api`,
  optional `data_integrity`; serves page routes and `/frontend/<path>`.
- `backend/loaders/xls_loader.py` — Isomerization DHA reader. HEADER!B2 = date, HEADER!B6 = metadata text with
  UID `<Run>_C<n>_S<n>_<n>` (regex `UID`). Sheets `CARBON_TABULAR(%WGT)`, `COMPONENT_LIST`, `OCTANE_NUMBERS`
  (B1:B4 = Lin-RON, Lin-MON, Cal-RON, Cal-MON).
- `backend/calculations/` — `constants.py` (components Paraffin, I-Paraffins, Aromatics, Naphthenes, Olefins,
  Unknown × C1–C15); `component_category.py` (COMPONENT_LIST → 15 reported components + carbon-range lumps
  "C3 & Below", "C3-C4" … "C8+" decided by elution position between n-paraffins, not RI);
  `yield_table.py` (Yield wof%).
- `backend/services/` — `dashboard_service.py` (process DHA folder, cumulative TOS), `online_analysis_service.py`
  (online `.txt` → `ONLINE_COLUMNS`, reactor mapping by `Sampled_reactor`), `reactor_map_service.py`
  (valve-opening R1–R8 states), `run_plan_service.py` (+ root `RunPlan.py`), `calculation_table_service.py`
  (Base table), `custom_table_service.py` (safe AST formula engine), `excel_export_service.py`, `run_data.py`
  (RunData snapshots), `historian.py` (SQLite per run).
- `backend/reforming/` — self-contained Reforming package (does not import isomerization code): `dha_loader.py`,
  `unknowns.py`, `service.py`, `operating.py`, `sync_source.py`, `routes.py` (its own Run Plan parser was retired;
  the shared `run_plan_service.py` parses the Run Plan for both processes).
- `features/data_integrity/` — removable plug-in (own blueprint, HTML/JS/CSS, README).
- `frontend/` — static HTML pages + vanilla JS (Chart.js, Lucide icons, no build step). `navigation.js` builds the
  top nav, Run Number box, Process selector/badge (`window.ILSProcess`), reset button.
  `reactor_map.html` is a large self-contained page.
- `scripts/` — `ValveOpening.py`, `build_static_snapshot.py`.
- Docker: `Dockerfile` + `docker-compose.yml` (gunicorn `app:app` on 0.0.0.0:5001, `data/` mounted at `/app/data`,
  RunData in volume `dashboard-rundata`); env overrides `DASHBOARD_HOST/PORT/OPEN_BROWSER`,
  `DASHBOARD_SOURCE_DIRECTORY`, `DASHBOARD_REACTOR_SOURCE_DIRECTORY`, `DASHBOARD_RUN_PLAN_FILE`.

## Pages (nav order)
Runs `/` (`run_data_home.html`) → Run Plan (`run_plan.html`, shared by all processes) → Analysis: Offline
(`index.html`), Online (`online_analysis.html`) → Calculation: Calculation table, Custom table → Data Integrity
(`/data-integrity`) → Plots → Summary Dashboard (`plot_dashboard.html`) → History (`history.html`).

## API
- `/api`: `health`, `settings`, `run-number` (GET/POST), `browse-folder`, `process` (DHA folder),
  `browse-reactor-folder`, `process-reactor-map`, `browse-online-file`, `process-online`,
  `apply-online-reactor-map`, `browse-run-plan-file`, `process-run-plan`, `feed-properties`,
  `process-calculation-base`, `calculate-yield-table`, `custom-table/{validate-formula,calculate,inspect-cell}`,
  `export-xlsx`.
- `/api/reforming`: `process`, `settings`, `sync-source` (GET/POST), `process-run-plan`, `operating-data`.
- `/api/run-data/runs` (GET list, POST save), `/api/run-data/runs/<run_id>` (GET).
- `/api/historian`: `runs`, `runs/<n>/exists`, `runs/<n>`, `save`, `compare`.
- `/api/data-integrity/{config,analyze}`.

## State model
All working data lives in the browser tab's **sessionStorage** (use one tab across pages). Keys:
`ils_run_number`, `ils_process`, `runPlanDashboardState`, `ils_feed_properties`, `dhaDashboardState` (offline),
`dhaOnlineState`, `dhaDateTimeFilter`, `ils_base_table_state`, `ils_yield_table_state`, `ils_custom_table_state`,
`ils_custom_columns`, `ils_plot_preferences`, `ils_reforming_offline`, `ils_reforming_carbon_state`,
`ils_reforming_sync`; localStorage `ils_reforming_autosync`. `historian_save.js` (`STATE_KEYS`) and
`run_data.js` (`sourceKeys`) list what gets saved — add new keys there. **Save Run Details** writes a gzip JSON
snapshot to `RunData/` (max 25 MB, id = 32-hex); re-saving the same Run Number offers cancel / replace latest /
new version. History stores runs in `Historian/Run_<n>.sqlite` and compares tables between runs.
Static JS/CSS use `?v=N` cache-busters — bump them when changing a file.

## Isomerization calculations
- Online tags: temperatures `10i1TIC02` (R1–4) / `10i2TIC02` (R5–8), pressures `10i1PIC01` / `10i2PIC01`,
  N2 flows `10i1FIC01..04` (R1–4) / `10i2FIC01..04` (R5–8), feed `01i14FIC01..08`, `01i14FI01`, GC `ESTD_H2`,
  `ESTD_N2`, `Sampled_reactor`.
- Base table (`reconstruct_base_table`): `TOS[h]` from first timestamp; `Naphtha_online = 100 − (ESTD_H2+ESTD_N2)`;
  `H2_out = N2/(ESTD_N2/100)·(ESTD_H2/100)·0.0416·2`; `Naphtha_out = N2/(ESTD_N2/100)·(Naphtha_online/100)·0.0416·MW`;
  `Carbon_out = Naphtha_out·Carbon/100`; `Naphtha_in = Carbon_out/(Carbon/100)`;
  `Naphtha/H2 = Naphtha_online·MW/(ESTD_H2·2)`. Carbon and MW come from Run Plan feed properties.
- Yield (wof%): each COMPONENT_LIST row is matched to the nearest Base row within ±60 min (same reactor preferred,
  ties → earlier), value × `Naphtha_out/Naphtha_in`; `Gas` = C3&Below + i/n-butane etc., `C5+` = (C3…n-Octane
  range) − Gas, `H2_Consumption` = range − 100. Missing match / bad Naphtha → explicit `ERROR: ...` cells, never 0.
- Plots: condition filter uses Run Plan DOE Start/End dates; colours = reactors, marker shapes = DOE conditions;
  optional centred 3/5/7-point moving average; paper-size PNG at 300 DPI. Summary Dashboard: 12 plot slots
  (3×4) + one table snapshot, A4 print/PDF.
- Custom table: Excel-like formulas evaluated by a whitelisted AST evaluator (no `eval`), cycle detection,
  cell lineage inspector, CSV and JSON template import/export.
- Data Integrity: per Run/Condition/Reactor/Parameter stats and MAD-based outlier flags; never modifies data.

## Universal Run Plan template (v6.4.1) — `backend/services/run_plan_template.py`
- Detected by the Plan row "Reactor role"; other RunPlan.xlsx files keep the fixed ranges in `RunPlan.py`.
- Plan: B1 Run ID, H1 Start date, B2 Objective, B3 Lab notebook ref., B4 Feed; catalyst loading rows 8-22 (Reactor role
  Catalyst/Inert/Not used ...). Active reactors = role Catalyst or Inert.
- DOE: header row 10, conditions from row 11 (kept when T, P or space velocity is filled), Catalyst from the Plan;
  row 9 planned hours → `doe.planned`. Step 0 pre-run (rows 108-259): steps 110-139 (A..T), totals 140/141, settings
  143-151 (feed cut-in = DOE C11/C59, pre-run start ...), chart settings 153-159 (phase names, right axis), graph data,
  2 Excel charts → `doe.pretreatment` {columns, rows, totals, settings, profile}; `profile` from `prerun_profile()`.
- Feed: tables tbl_Feed, tbl_comp, tbl_compType, tbl_gas + gas feed settings → `feed.tables`; flat `feed.rows` start
  with Carbon, Hydrogen, Molecular Weight. Plan info gets Feed SL ID, Feed molecular weight, Feed Cut-In.
- Run Plan page tabs: Feed (4 cards), Plan, DOE, **Pre-run** (steps up to Remarks + Chart.js chart per block).

## Online Analysis units (v6.4.2) — `backend/services/online_units.py`, `/api/online-units`
- Units selector on the Online Analysis table: Normalised mol% (imported ESTD values), Mass flow rates (g/h), Volumetric
  flow rates (Nl/h), TOS carbon of each molecule (g C/h). MassBal workbook formulas, argon = internal standard:
  F_r = 01i14FI01 · FIC_r / ΣFIC; F_Ar,r = F_r · w_Ar; m_i = y_i·MW_i/(y_Ar·39.948) · F_Ar,r; V_out = FIC_r/1000 ·
  y_Ar,feed / y_Ar, V_i = y_i/100 · V_out; C_i = 12.011 · nC_i / MW_i · m_i. MWs / carbon atoms = workbook standards.
- Ar in the feed gas and w_Ar only from the Run Plan Feed → Gas feed composition (feed gas MWs of the workbook; earlier
  template: "Gas composition (mol%)" block). Gas feed of a line (v6.4.3): export (01i14FIC0r, 01i14FI01) → else the Run
  Plan DOE condition at that time ("Total gas (Nl/h)" / "Gas Flow (NmL/h)"). Without 01i14FI01: F_Ar,r = FIC_r/1000 /
  22.414 · y_Ar,feed/100 · 39.948. No inputs on the page: the collapsed "Conversion basis" block under the table is
  read-only and says what is missing in the Run Plan. TOS from the Run Plan Feed Cut-In. `ESTD_Etylene` = Ethylene.
  Status OK / `ERROR: …` per line. Liquid feed analysis is not a Run Plan entry (comes later with the liquid product).

## General_MB (v6.5.0) — Internal Standard from the bypass lines
- `window.ILSProcess` values `isomerization`, `reforming`, `general_mb` (`isGeneralMB()`); General_MB uses the
  Isomerization pipeline everywhere except Online Analysis. Isomerization / Reforming: Online shows mol% only.
- Online (General_MB): Internal Standard — / Argon / N2 (`dhaOnlineState.internalStandard`, panels in `mbPanels`); units
  other than mol% need an IS. `/api/online-units` takes `internal_standard`; returns `feed_gas_is[]` (per DOE condition
  Block · Condition No.: bypass_lines, is_mol_pct, mixed_mol_pct, sum, mixed_mw, is_wt_pct, is_rsd_pct, error) and
  `avg_is_flow[]` (condition × R1–R8: g/h or `ERROR …`). Condition window per reactor: Start → End, else Start + Duration,
  else next condition of the reactor, else end of data; bypass lines = Reactor 0 with GC values inside the condition's
  window (parallel blocks share them). Side panel next to the table; Conversion basis collapsed at the bottom.
- R08 + `RunPlan_MassBalance_SS_filled.xlsx`, Argon: Block-1 C1 44 lines 5.1572 / 95.9625 mol%, 9.2933 wt%, R1 0.1267 g/h;
  Block-2 C1 36 lines 5.0994 mol%, R5 0.2520, R6 0.2455 g/h.

## Reforming (v6.4) — details in `REFORMING_PROGRESS.md`
- Process selector after Run Number on the shared Run Plan page; switching clears the loaded Run Plan and stays on
  `run_plan.html`. The process is never inferred from the workbook.
- **Unified Run Plan** (2026-10-28): both processes use one `RunPlan.xlsx` format — `Plan` (objective, R1–R8 Catalyst
  Loading Plan, optional column-A labels with values in column C: `Feed SL ID`, `Feed Cut-In`, `Feed molecular weight`),
  `DOE` (header row 10, data from row 11, optional column N `Catalyst`; blank inherits the Plan catalyst of that reactor),
  `Feed` (`E2` Carbon, `E3` Hydrogen, `E4` MW). Payload has `planData.info` and `summary.active_reactors`. Legacy
  reforming workbooks (`Run Information` row or `Feed DHA` sheet) are rejected with a migration message.
  `data/RunPlan_Reforming.xlsx` is a reforming example in this format (R1 PS-210, DOE 1-3 PS-210, 4-6 R-434).
- DHA: Table-1 = CARBON_TABULAR with the Unknown row split by Carbon#; Table-2 = unknown-peak audit; Table-3 =
  RON, MW, Carbon, Hydrogen, SG. Unknown Carbon# rule: lumped `Cn Unknowns` rows keep n; `Unidentified` rows take
  the neighbours' Carbon# if equal, else the previous identified peak's (leading → next; none → round(RI/100));
  clamp C1–C15; a lump already counted in a family (Below C4 → Olefins C4) is not double counted.
  UID is SAMPLE_ID trimmed to e.g. `R18_C1_S1_004`.
- Calculation: Base table uses temperature `10i2TIC01`; Yield tab hidden; tab "Reforming CARBON_TABULAR(%WGT)"
  (Date, Condition, TOS from Feed Cut-In, Reactor, UID, 6 families × C1–C15, Total, physical properties) with
  CSV export (2 header rows, dates written as `="dd/mm/yyyy hh:mm"`) and **Export Complete** (operating data
  joined to DHA within −10..+60 min).
- SharePoint/OneDrive sync: reads a locally synced "Online DHA Results" folder (`config/reforming_sync.json`),
  auto-syncs every 5 min when file signatures change.
- Open items: "Sync from Online Analysis" fallback still uses isomerization temperature mapping; reforming wof%
  (Reactor1 sheet) not done; History / Summary Dashboard plan tables assume R1–R8 columns.

## Working conventions seen in this codebase
- Keep isomerization behaviour unchanged when adding reforming work; gate reforming code on
  `window.ILSProcess` / `process === 'reforming'`.
- Make previous versions recoverable (versioned folders, `backups/<date>_<topic>/`); record changes in
  `CHANGELOG.md`, `README.md` and, for reforming, `REFORMING_PROGRESS.md`.
- Errors are shown explicitly in tables rather than silently replaced with zero.

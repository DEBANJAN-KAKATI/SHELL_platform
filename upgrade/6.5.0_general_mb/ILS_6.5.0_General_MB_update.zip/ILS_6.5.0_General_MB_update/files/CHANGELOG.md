## 6.5.0 (2026-11-06) — Process General_MB: Internal Standard measured in the bypass lines
- Third process **General_MB** on the Run Plan page (next to Isomerization and Reforming). It uses the Isomerization
  pages; only the Online Analysis page changes.
- **Isomerization / Reforming**: the Online Analysis table shows Normalised mol% only (no Units, no Internal Standard).
- **General_MB → Online Analysis**: Internal Standard **— / Argon / N2** (default —: mol% only). With Argon or N2 the
  Units g/h, Nl/h and g C/h become available and a **side panel** next to the table shows, per Run Plan DOE condition
  (Block · Condition No.):
  - **Feed gas composition · Internal Standard**, measured in the bypass (reactor 0) GC lines inside the condition window
    (raw ESTD averages): IS mol%, IS wt%, mixed gas mol% (every other gas; N2 counts for Argon-IS, Argon for N2-IS), sum,
    mixed gas MW, IS spread (RSD) and the Run Plan Argon for comparison;
  - **Average IS flow to reactor [g/h]** (workbook R#_MB!F5 = Gas!G20) per active reactor.
  Formulas: w_IS = y_IS·MW_IS / (y_IS·MW_IS + y_mix·MW_mix); F_IS,r = 01i14FI01 · FIC_r/ΣFIC · w_IS, else
  FIC_r/1000 / 22.414 · y_IS,feed/100 · MW_IS; m_i = y_i·MW_i/(y_IS·MW_IS)·F_IS,r; V_out = FIC_r/1000 · y_IS,feed/y_IS.
- Table: new column Condition; bypass lines get Status "BYPASS – feed gas of …" (grey) and stay the bypass when the
  Reactor Map is ON. Explicit errors: no DOE condition, no bypass line in a condition, IS peak missing.
- The Conversion basis block stays collapsed at the bottom. Historian / Save Run Details store the two panel tables.
- Tests: R3 and R08 worked examples, the workbook Gas sheet (I37, G20) reproduced from a bypass line, error cases.
  Fixture `tests/fixtures/run_plan/RunPlan_MassBalance_SS_filled.xlsx` (gas feed composition = measured bypass gas).

## 6.4.3 (2026-11-05) — Online Analysis units: everything from the export and the Run Plan
- GC exports without gas flow columns (e.g. `R3-C2-S1_9-06-23.txt`) showed "ERROR: no gas feed to Rr (01i14FIC0r = empty)"
  on every line. The gas feed of a line now comes from the export line, else from the **Run Plan DOE** (gas flow of the
  condition running for that reactor at that time: "Total gas (Nl/h)", older files "Gas Flow (NmL/h)"). Without
  01i14FI01 the Ar flow is n_Ar · MW_Ar = FIC_r/1000 / 22.414 · Ar mol%/100 · 39.948. New column "Flow source".
- **No inputs on the Online page any more**: Ar in the feed gas comes only from the Run Plan (Feed → Gas feed
  composition). The Conversion basis block is read-only; it opens in red and says what is missing in the Run Plan.
- `ESTD_Etylene` is read as Ethylene.
- Run Plans of the earlier template layout: the "Gas composition (mol%)" block under "Gas feed" is read as the Gas feed
  composition; header rows inside the liquid list are skipped.

## 6.4.2 (2026-11-05) — Online Analysis units (g/h, Nl/h, g C/h)
Process selection (Isomerization / Reforming) is unchanged.
- **Online Analysis → Units**: Normalised mol% (as imported), Mass flow rates (g/h), Volumetric flow rates (Nl/h) and
  TOS carbon of each molecule (g C/h) per GC injection, with argon as internal standard and the formulas and molecular
  weights of the MassBal workbook (Ver2.2): F_Ar,r = 01i14FI01 · FIC_r/ΣFIC · w_Ar, m_i = y_i·MW_i/(y_Ar·39.948)·F_Ar,r,
  V_i = y_i/100 · FIC_r/1000 · y_Ar,feed/y_Ar, C_i = 12.011·nC_i/MW_i·m_i. Ar mol% / wt% of the feed gas from the Run Plan
  gas table (or entered), TOS from the Run Plan Feed Cut-In. Explicit ERROR status for bypass lines, missing argon peak,
  stopped gas feed and missing feed argon. Mass and carbon flows reproduce the workbook's R6_MB values exactly; the
  workbook's total volumetric flow (R#_MB!D86) mixes g/h and NmL/h, so the argon balance it intends is used.
- The conversion basis (Ar inputs, formula, MW table) is collapsed under the table with a one-line summary.
- Online loader: the export is read as mbcs, cp1252 or UTF-8 and its 'ÿ' marker is read as "no value";
  `ESTD_C6 Above` is taken from `Area_C6 Above` when the export shifts that column.
- New `backend/services/online_units.py`, `POST /api/online-units`, `frontend/css/online_units.css`,
  tests `tests/test_online_units.py` (fixtures in `tests/fixtures/online/`).

## 6.4.1 (2026-11-04) — Universal Run Plan template: Feed in 4 tables, Pre-run (DOE Step 0) with charts
Process selection (Isomerization / Reforming) is unchanged.
- New reader `backend/services/run_plan_template.py` for the universal Run Plan template (detected by the Plan row
  "Reactor role"); `run_plan_service.py` uses it for template files, older RunPlan.xlsx files keep the fixed ranges.
- Feed tab: feed properties as tiles and the Liquid components, Group-type summary and Gas feed composition tables as
  separate cards (totals, 100 % check, empty rows hidden with a "Show empty rows" switch). Carbon, Hydrogen and
  Molecular Weight stay the first feed rows, so the Calculation table, Plots and Custom table read them as before.
- Plan tab: Run ID, start date, lab notebook, feed and the catalyst loading plan with Reactor role; active reactors =
  role Catalyst or Inert. DOE tab: only filled conditions, planned hours and run end above the table.
- New **Pre-run** tab: the DOE Step 0 steps up to Remarks (Step, Block, Start/End, Phase, Gas, temperatures, ramp,
  hold, pressure, pressure change) and one chart per block — temperature coloured by phase, pressure (or the gas /
  liquid flow chosen in the template) dashed on the right axis.
- Plan info "Feed Cut-In" (Reforming TOS zero) is taken from the pre-run feed cut-in of the first active reactor's
  block, else the start of its first DOE condition; "Feed SL ID" and "Feed molecular weight" from the Feed table.
- Launcher: `run_app.py` opens a running dashboard only when it is this folder (`/api/health` reports `root`);
  another copy on the port → next free port. The navigation shows the running version (vX.Y.Z).
- Template `tests/fixtures/run_plan/RunPlan_Template_Feed_SS.xlsx` (blank), filled example
  `RunPlan_Isomerisation_Rheinland.xlsx`, script `scripts/run_plan_examples/prerun_doe.py`, tests
  `tests/test_run_plan_template.py` (`python -m pytest -q`).

## Next — Unified Run Plan
- Unified Isomerization and Reforming on the shared `RunPlan.xlsx` format (`Plan`, `DOE`, `Feed`).
- Added optional Plan metadata (`Feed SL ID`, `Feed Cut-In`, and `Feed molecular weight`), optional DOE column N `Catalyst`, and `summary.active_reactors`.
- Removed the legacy Reforming Run Plan page and reject legacy Reforming workbooks with a migration message.

## Unreleased — Windows launcher fixes
- Python 3.15+ was rejected (only 3.9-3.14 were accepted), so the launcher downloaded Python from python.org, which company
  proxies block with 403 Forbidden. Any installed Python 3.9+ is now used, including the Python Install Manager folder
  `%LOCALAPPDATA%\Python\pythoncore-*`; an installed Python that already has the packages is used directly with no downloads;
  if a venv cannot be created the installed Python is used directly instead of downloading one.
  Python on PATH is also found with the built-in `%~$PATH:` search, not only `where`.
- `requirements.txt`: pandas 3 on Python 3.15+ (pandas 2 has no Windows packages for it); pandas 2 otherwise.
- Base table TOS/sorting: ISO timestamps are parsed as ISO (pandas 3 applied dayfirst to them: 2026-10-09 became 10 September).
  Online/Base/Yield/Run Plan/Reactor Map/operating-data results are identical on pandas 2.3.3 and 3.1.0.
- A failed package update no longer stops the dashboard when the installed packages work; offline install from a `wheels`
  folder; clear guidance when pypi.org or python.org answer 403.
- `run_app.py`: if port 5001 is in use or reserved by Windows it uses the next free port; if the dashboard is already running it
  opens it instead of failing.
- `run_dashboard.bat` now uses an installed Python 3.9-3.14 to create `.venv` (or `.venv-local` beside a copied/broken `.venv`)
  instead of always downloading Python; the private runtime is downloaded only when no usable Python is installed.
- Fixed the private runtime: the get-pip URL was always empty (variable set and used in one block), an existing runtime
  without pip was never repaired, and `python312._pth` did not include the application folder, so `import app` failed.
- Packages are installed only when missing or when `requirements.txt` changes; downloads fall back from curl to PowerShell (TLS 1.2).
- Exit codes are checked with `neq 0`, so a Python that crashes (negative exit code) is no longer treated as success;
  install folders are scanned with `dir` and `python312._pth` is written line by line.
- Tested under Wine: Python installed but not on PATH, no Python (runtime left by the old launcher), and a broken copied `.venv`.
- `.gitattributes` keeps `.bat`/`.cmd`/`.ps1` files in CRLF (cmd.exe misreads labels in LF-only batch files).
- Folder/file Browse falls back to the PowerShell dialog when the tkinter picker cannot start (the private runtime has no tkinter).

## 6.4.0 (2026-10-14) — Reforming process
- Process selector (Isomerization / Reforming) on the Run Plan page; reforming Run Plan page, Offline hooks,
  Calculation tab "Reforming CARBON_TABULAR(%WGT)" with CSV export. Isomerization behaviour unchanged.
- Reforming DHA: lumped "Cn Unknowns" rows in COMPONENT_LIST use their given Carbon#; remaining "Unidentified"
  rows use the neighbour rule; a lump already counted in a CARBON_TABULAR family (Below C4 -> Olefins C4) is not
  counted twice. See REFORMING_PROGRESS.md.

### 6.0.0 - 2026-10-03
- Copied the latest v5.1 application into a standalone v6.0 folder, preserving v5.1.
- Includes the redesigned full-width run workspace and automatic saved-run metadata.
- Includes the Summary Dashboard, twelve plot slots, table source and filter options, card-sized captures, and A4 Print / PDF workflow.
- Preserves existing application data, RunData snapshots, and Historian records. Generated virtual environments and caches are excluded from the copy.

### 4.1.0 - 2026-09-21
- Added Custom Table Studio (`/custom-table`) enabling Excel-like formula flexibility.
- Implemented Dual-Mode Builder (Guided Visual Builder for non-programmers + Excel Formula Bar for power users).
- Added safe AST expression evaluator (zero arbitrary code execution, safe division by zero, DAG cycle detection).
- Added Cell Lineage & Audit Explain inspector to verify intermediate calculations and inputs.
- Added support for cross-referencing Base Table, Offline Table-2, Yield Table, and Demo datasets.
- Added CSV export and JSON calculation template import/export.

### 4.0.0 - 2026-09-15
- Yield table wof% calculation synchronization.
- Base reactor conditions and feed property bindings.

### 3.4.0 - 2026-09-10
- Added a Reactor Map tab beside Table-3 · Octane Table.
- Linked the tab to the packaged valve-opening dashboard at /frontend/reactor_map.html.
- Restyled the Reactor Map with the main dashboard palette, typography, cards, filters, table, and responsive behavior.
- Added tab/route regression checks and a complete v3.3.0 rollback archive.
- No DHA or valve-state calculation logic was changed.

### 3.3.0 - 2026-09-09
- Added Table-3 · Octane Table as a third tab beside Tables 1 and 2.
- Extracts Lin-RON, Lin-MON, Cal-RON, and Cal-MON from OCTANE_NUMBERS!B1:B4 for each XLS file.
- Added Table-3 processed KPI and file-level partial/error reporting.
- Formats all displayed numeric table values to two decimal places without altering extracted numeric data.
- Added automated tests for octane cell mapping and updated documentation.

### 1.3.2 - 2026-09-08
- Fixed Table-1 returning zero rows when the optional Unknown column is absent or labeled Unknowns/Unidentified.
- Table-1 now detects the carbon header row and all available worksheet columns dynamically.
- Added separate Table-1 and Table-2 processed KPIs so partial processing is visible.
- Preserved revised HC_category.py Table-2 logic and restored the full startup package.

## Changelog

### 1.2.0 - 2026-09-08
- Added a Components filter dropdown to the DHA Data table.
- Added Paraffin, I-Paraffins, Aromatics, Naphthenes, and Olefins multi-select options.
- Added Select all and Clear controls and an active-filter summary.
- Preserved text search and folder processing behavior.
- Added safer JSON response handling for API errors.

### 1.1.0 - 2026-09-08
- Consolidated the component views into one DHA Data table.
